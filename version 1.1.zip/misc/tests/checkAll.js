var checkboxes = document.querySelectorAll("ul input");
for(var i = 0; i < checkboxes.length; i++) {
    checkboxes[i].checked = true;
}
